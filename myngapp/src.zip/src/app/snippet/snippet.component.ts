import { Component } from '@angular/core';

@Component({
  selector: 'snippet-root',
  templateUrl: './snippet.component.html',
  styleUrls: ['./snippet.component.css']
})
export class SnippetComponent {
  title2 = 'Code Snippet';
}
