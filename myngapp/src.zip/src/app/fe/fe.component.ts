import { Component } from '@angular/core';

@Component({
    selector: 'fe-data',
    templateUrl: './fe.component.html',
    styleUrls: ['./fe.component.css']
})

export class FECompoment {
    name: String = 'Sharath';
    lastName: String = 'R';
    cell: Number = 88892772944;
    imagepath: String = "https://blobstore-ls-ge.run.aws-usw02-pr.ice.predix.io/v1/blob/images.jpg";

    getFullName(): string {
        return this.name + '' + this.lastName;
    }

}